package com.example.user.timerbaqbaeva;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {
    Button startButton, resetButton;
    TextView timertext;
    boolean isStarted=true;
    Timer timer;
    int timerCount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        startButton=findViewById(R.id.start);
        resetButton=findViewById(R.id.reset);

        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isStarted) {
                    timer=new Timer();
                    timer.scheduleAtFixedRate(new TimerTask() {
                        @Override
                        public void run() {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    int minute=timerCount/60;
                                    int seconds=timerCount/60;
                                    String secString =""+seconds;
                                    if (seconds<10){
                                        secString="0"+seconds;//09
                                }
                                    timertext.setText(minute+":" + secString);
                                    timerCount++;
                            }

                            });
                        }
                    }, 0,1000);
                    startButton.setText("PAUSE");
                }else{
                    startButton.setText("START");
                }
                isStarted=!isStarted; //true->false; false->true
                }
            });
    }}

